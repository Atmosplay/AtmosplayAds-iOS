//
//  PADecryptJSONResponseSerializer.h
//  Pods
//
//  Created by d on 20/7/2017.
//
//

#import "PANetworking.h"

@interface PADecryptJSONResponseSerializer : PAJSONResponseSerializer

@end
