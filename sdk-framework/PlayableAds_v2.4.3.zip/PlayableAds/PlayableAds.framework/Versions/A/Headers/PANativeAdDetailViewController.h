//
//  PANativeAdDetailViewController.h
//  PlayableAdsPreviewer
//
//  Created by Michael Tang on 2018/8/31.
//

#import "PAResponseModel.h"
#import <UIKit/UIKit.h>

@interface PANativeAdDetailViewController : UIViewController

- (void)setDetailModel:(PAResponseModel *)detailModel;

@end
