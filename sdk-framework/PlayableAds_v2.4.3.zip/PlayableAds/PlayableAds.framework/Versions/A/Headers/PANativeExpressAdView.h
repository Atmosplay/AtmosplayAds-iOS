//
//  PANativeExpressAdView.h
//  Pods
//
//  Created by Michael Tang on 2018/8/27.
//

#import <UIKit/UIKit.h>

@interface PANativeExpressAdView : UIView

/// report impression when display the native express ad.
- (void)reportImpressionNativeExpressAd;

@end
