//
//  PAConstants.h
//  Pods
//
//  Created by d on 20/7/2017.
//
//

#ifndef PAConstants_h
#define PAConstants_h

static NSString *const DecryptKey = @"cHUgQenkAmS5169iZcRABw8n";
static NSString *const SDKVersion = @"2.4.3";

#endif /* PAConstants_h */
