//
//  PALogDefaultFormatter.h
//  Pods
//
//  Created by d on 26/5/2017.
//
//

#import "PALogFormatter.h"
#import <Foundation/Foundation.h>

@interface PALogDefaultFormatter : NSObject <PALogFormatter>

@end
